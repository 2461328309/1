#python TEST_CS_ISTA_Net_plus_RB_DRUNK_SingleMatrix_Dataloader.py --cs_ratio 10
python TEST_CS_ISTA_Net_plus_RB_DRUNK_SingleMatrix_Dataloader_Deblock.py --cs_ratio 10

#python TEST_CS_ISTA_Net_plus_RB_DRUNK_SingleMatrix_Dataloader.py --cs_ratio 30
python TEST_CS_ISTA_Net_plus_RB_DRUNK_SingleMatrix_Dataloader_Deblock.py --cs_ratio 30

#python TEST_CS_ISTA_Net_plus_RB_SingleMatrix_Dataloader.py --cs_ratio 10
python TEST_CS_ISTA_Net_plus_RB_SingleMatrix_Dataloader_Deblock.py --cs_ratio 10

#python TEST_CS_ISTA_Net_plus_RB_SingleMatrix_Dataloader.py --cs_ratio 30
python TEST_CS_ISTA_Net_plus_RB_SingleMatrix_Dataloader_Deblock.py --cs_ratio 30

# python Train_CS_ISTA_Net_plus_RB_SingleMatrix_Dataloader.py --gpu_list 0 --cs_ratio 20
# python Train_CS_ISTA_Net_plus_RB_SingleMatrix_Dataloader.py --gpu_list 0 --cs_ratio 40
# python Train_CS_ISTA_Net_plus_RB_SingleMatrix_Dataloader.py --gpu_list 0 --cs_ratio 50

# python Train_CS_ISTA_Net_plus_RB_DRUNK_SingleMatrix_Dataloader.py --gpu_list 0 --cs_ratio 20
# python Train_CS_ISTA_Net_plus_RB_DRUNK_SingleMatrix_Dataloader.py --gpu_list 0 --cs_ratio 40
# python Train_CS_ISTA_Net_plus_RB_DRUNK_SingleMatrix_Dataloader.py --gpu_list 0 --cs_ratio 50
